
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "MFC2015.h"
#include "ChildView.h"
#include"MyShape.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	LBD = false;
	ShapeNum = 0;
	RBD = false;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.
	

	for (int i = 0; i < ShapeNum + 1; i++)
	{
		Shape[i]->Draw(&dc);
	}
	for (int i = 0; i < ShapeNum + 1; i++)
	{
		Shape[i]->Draw(&dc);
	}
}



void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	LBD = true;
	Shape[ShapeNum]->m_start = point;
	CWnd::OnLButtonDown(nFlags, point);
}


void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	LBD = false;
	Shape[ShapeNum]->m_end = point;
	ShapeNum++;
	Invalidate();
	CWnd::OnLButtonUp(nFlags, point);
}


void CChildView::OnRButtonDown(UINT nFlags, CPoint point)
{
	RBD = true;
	Shape[ShapeNum]->m_start = point;
	CWnd::OnRButtonDown(nFlags, point);
}


void CChildView::OnRButtonUp(UINT nFlags, CPoint point)
{
	RBD = false;
	Shape[ShapeNum]->m_end = point;
	ShapeNum++;
	Invalidate();
	CWnd::OnRButtonUp(nFlags, point);
}


void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{
	if (LBD)
	{
		Shape[ShapeNum]->m_end = point;
		Invalidate();
	}
	if (RBD)
	{
		Shape[ShapeNum]->m_end = point;
		Invalidate();
	}
	CWnd::OnMouseMove(nFlags, point);
}
