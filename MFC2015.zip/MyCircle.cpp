#include"stdafx.h"
#include"MyShape.h"
#include"MyCircle.h"

CMyCircle::CMyCircle(void)
{
}
CMyCircle::~CMyCircle(void)
{
}
void CMyCircle::Draw(CDC *pDC)
{
	//pDC->Ellipse(m_start.x, m_start.y, m_end.x, m_end.y);
	CBrush brush1(RGB(0, 255, 255));
	CDC memdc;
	memdc.CreateCompatibleDC(pDC);
	memdc.SelectObject(&brush1);
	pDC->SelectObject(&brush1);
	pDC->BitBlt(m_start.x, m_start.y, m_end.x, m_end.y, &memdc, 0, 0, SRCCOPY);
	pDC->Ellipse(m_start.x, m_start.y, m_end.x, m_end.y);
}