#pragma once
class CMyShape
{
public:
	CMyShape(void);
	~CMyShape(void);

	CPoint m_start;
	CPoint m_end;

	virtual void Draw(CDC *pDC);
};