#pragma once

class CMyRect :public CMyShape
{
public:
	CMyRect(void);
	~CMyRect(void);

	void Draw(CDC *pDc);
};