#pragma once

class CMyCircle :public CMyShape
{
public:
	CMyCircle(void);
	~CMyCircle(void);

	void Draw(CDC *pDc);
};