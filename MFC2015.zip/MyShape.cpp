#include"stdafx.h"
#include"MyShape.h"

CMyShape::CMyShape(void)
{
}

CMyShape::~CMyShape(void)
{
}
void CMyShape::Draw(CDC *pDC)
{

}