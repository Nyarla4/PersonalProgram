#include"stdafx.h"
#include"MyShape.h"
#include"MyRect.h"
#include"resource.h"

CMyRect::CMyRect(void)
{
}
CMyRect::~CMyRect(void)
{
}
void CMyRect::Draw(CDC *pDC)
{
	CBitmap bitmap;
	bitmap.LoadBitmap(IDB_BITMAP1);
	CBrush brush(&bitmap);
	CDC memdc;
	memdc.CreateCompatibleDC(pDC);
	pDC->SelectObject(&brush);
	pDC->Rectangle(m_start.x, m_start.y, m_end.x, m_end.y);
	//BOOL StretchBlt(m_start.x , m_start.y, m_end.x-m_start.x, m_end.y-m_start.y,pDC, 0, 0, int nSrcWidth, int nSrcHeight, DWORD dwRop);
	//pDC->BitBlt(m_start.x, m_start.y, m_end.x, m_end.y, &memdc, 0, 0, SRCCOPY);
}