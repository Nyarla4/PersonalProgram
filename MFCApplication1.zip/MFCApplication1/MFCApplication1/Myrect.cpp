#include"stdafx.h"
#include"Myrect.h"

Rect::Rect()
{
}

Rect::~Rect()
{
}