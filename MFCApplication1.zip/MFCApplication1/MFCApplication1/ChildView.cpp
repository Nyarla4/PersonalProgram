
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "MFCApplication1.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	rect_num = 0;
	c_rect = (RGB(0, 255, 255));
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_MOUSEHOVER()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); 
	CBrush brush(c_rect);
	dc.SelectObject(&brush);
	for (int i = 0; i < rect_num; i++)
	{
		dc.Rectangle(rect[i].r_start.x, rect[i].r_start.y, rect[i].r_end.x, rect[i].r_end.y);
	}
	dc.Ellipse(mouse.x - 10, mouse.y - 10, mouse.x + 10, mouse.y + 10);
}



void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	rect[rect_num].r_start = point;
	CWnd::OnLButtonDown(nFlags, point);
}


void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	rect[rect_num].r_end = point;
	rect_num++;
	Invalidate();
	CWnd::OnLButtonUp(nFlags, point);
}


void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == 'R')
		c_rect = (RGB(255, 0, 0));
	if (nChar == 'G')
		c_rect = (RGB(0, 255, 0));
	if (nChar == 'B')
		c_rect = (RGB(0, 0, 255));
	Invalidate();
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CChildView::OnMouseHover(UINT nFlags, CPoint point)
{
	mouse = point;
	Invalidate();
	CWnd::OnMouseHover(nFlags, point);
}
